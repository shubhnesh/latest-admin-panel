import 'package:flutter/material.dart';
import 'package:rdx_admin/core/theme/text_styles.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/responsive_size.dart';
import 'rdx_text_field.dart';

class RdxSearchBar extends StatefulWidget {
  final String hintText;
  final TextEditingController? controller;

  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;

  final VoidCallback? onClear;

  final double? width;
  final double? height;

  final EdgeInsetsGeometry? margin;
  final EdgeInsetsGeometry? padding;

  final Widget? leading;
  final Widget? trailing;

  final bool enabled;
  final bool readOnly;
  final bool autofocus;

  final FocusNode? focusNode;
  final TextInputAction textInputAction;
  final TextInputType? keyboardType;

  final Color? backgroundColor;
  final Color? borderColor;
  final Color? textColor;
  final Color? hintColor;

  final double borderRadius;
  final double borderWidth;

  final TextStyle? textStyle;
  final TextStyle? hintStyle;

  final bool showClearButton;

  const RdxSearchBar({
    super.key,
    this.hintText = 'Search...',
    this.controller,
    this.onChanged,
    this.onSubmitted,
    this.onClear,
    this.width,
    this.height,
    this.margin,
    this.padding,
    this.leading,
    this.trailing,
    this.enabled = true,
    this.readOnly = false,
    this.autofocus = false,
    this.focusNode,
    this.textInputAction = TextInputAction.search,
    this.keyboardType,
    this.backgroundColor,
    this.borderColor,
    this.textColor,
    this.hintColor,
    this.borderRadius = 10,
    this.borderWidth = 1,
    this.textStyle,
    this.hintStyle,
    this.showClearButton = true,
  });

  @override
  State<RdxSearchBar> createState() => _RdxSearchBarState();
}

/// Shared page toolbar that keeps search and page actions in a stable layout.
class RdxSearchToolbar extends StatelessWidget implements PreferredSizeWidget {
  final String hintText;
  final TextEditingController? controller;
  final ValueChanged<String>? onChanged;
  final List<Widget> actions;
  final EdgeInsetsGeometry? padding;

  const RdxSearchToolbar({
    super.key,
    this.hintText = 'Search...',
    this.controller,
    this.onChanged,
    this.actions = const [],
    this.padding,
  });

  @override
  Size get preferredSize => const Size.fromHeight(64);

  @override
  Widget build(BuildContext context) {
    final narrow = MediaQuery.sizeOf(context).width < 480;
    final search = RdxSearchBar(
      height: RdxTextField.singleLineHeight(context),
      hintText: hintText,
      controller: controller,
      onChanged: onChanged,
    );

    if (narrow && actions.isNotEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          search,
          SizedBox(height: context.h(10)),
          Wrap(
            spacing: context.w(10),
            runSpacing: context.h(8),
            alignment: WrapAlignment.end,
            children: actions,
          ),
        ],
      );
    }

    return SizedBox(
      height: preferredSize.height,
      child: Row(
        children: [
          Expanded(child: search),
          for (final action in actions) ...[
            SizedBox(width: context.w(14)),
            action,
          ],
        ],
      ),
    );
  }
}

class _RdxSearchBarState extends State<RdxSearchBar> {
  late final TextEditingController _internalController;
  late final FocusNode _internalFocusNode;

  bool _ownsController = false;
  bool _ownsFocusNode = false;

  TextEditingController get _controller =>
      widget.controller ?? _internalController;

  FocusNode get _focusNode => widget.focusNode ?? _internalFocusNode;

  @override
  void initState() {
    super.initState();

    if (widget.controller == null) {
      _internalController = TextEditingController();
      _ownsController = true;
    } else {
      _internalController = widget.controller!;
    }

    if (widget.focusNode == null) {
      _internalFocusNode = FocusNode();
      _ownsFocusNode = true;
    } else {
      _internalFocusNode = widget.focusNode!;
    }

    _controller.addListener(_controllerListener);
    _focusNode.addListener(_focusListener);
  }

  @override
  void dispose() {
    _controller.removeListener(_controllerListener);
    _focusNode.removeListener(_focusListener);

    if (_ownsController) {
      _internalController.dispose();
    }

    if (_ownsFocusNode) {
      _internalFocusNode.dispose();
    }

    super.dispose();
  }

  void _controllerListener() {
    if (mounted) {
      setState(() {});
    }
  }

  void _focusListener() {
    if (mounted) setState(() {});
  }

  void _clear() {
    _controller.clear();
    widget.onClear?.call();
    widget.onChanged?.call('');
  }

  @override
  Widget build(BuildContext context) {
    final bool hasText = _controller.text.isNotEmpty;
    final colors = AppColors.of(context);

    final double effectiveHeight = widget.height ?? context.h(42);

    return Container(
      width: widget.width,
      height: effectiveHeight,
      margin: widget.margin,
      padding: widget.padding ??
          EdgeInsets.symmetric(
            horizontal: RdxTextField.horizontalPad(context),
          ),
      decoration: BoxDecoration(
        color: widget.backgroundColor ?? Colors.white,
        borderRadius: BorderRadius.circular(context.h(8)),
        border: Border.all(
          color: widget.borderColor ?? colors.border,
          width: widget.borderWidth,
        ),
      ),
      child: Row(
        children: [
          widget.leading ??
              Icon(
                Icons.search_rounded,
                size: context.h(25),
                color: widget.hintColor ?? colors.textMuted,
              ),
          SizedBox(width: context.w(9)),
          Expanded(
            child: TextField(
              controller: _controller,
              focusNode: _focusNode,
              enabled: widget.enabled,
              readOnly: widget.readOnly,
              autofocus: widget.autofocus,
              textInputAction: widget.textInputAction,
              keyboardType: widget.keyboardType,
              maxLength: 20,
              onChanged: widget.onChanged,
              onSubmitted: widget.onSubmitted,
              style: widget.textStyle ??
                  AppTextStyles.label(context).copyWith(
                    color: widget.textColor ?? colors.textPrimary,
                  ),
              decoration: InputDecoration(
                hintText: widget.hintText,
                hintStyle: widget.hintStyle ??
                    AppTextStyles.label(context).copyWith(
                      color: widget.hintColor ?? colors.textMuted,
                    ),
                counterText: '',

                // No background inside the TextField.
                filled: false,
                fillColor: Colors.transparent,

                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                disabledBorder: InputBorder.none,

                isDense: true,
                contentPadding: EdgeInsets.zero,
              ),
            ),
          ),
          if (widget.showClearButton && hasText)
            GestureDetector(
              onTap: _clear,
              child: Padding(
                padding: EdgeInsets.only(
                  left: context.w(8),
                ),
                child: Icon(
                  Icons.close_rounded,
                  size: context.h(16),
                  color: colors.textMuted,
                ),
              ),
            ),
          if (widget.trailing != null) ...[
            SizedBox(width: context.w(8)),
            widget.trailing!,
          ],
        ],
      ),
    );
  }
}
